<?php

echo "Dev server running at localhost temporarily for testing purposes.\n";

?>